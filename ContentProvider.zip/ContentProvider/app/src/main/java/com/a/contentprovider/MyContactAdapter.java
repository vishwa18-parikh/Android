package com.a.contentprovider;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;


public class MyContactAdapter extends BaseAdapter {

    Context context;
    ArrayList<ContactModel> contactModelArrayList;
    String TAG = "MyContactAdapter";

    public MyContactAdapter(Context context, ArrayList<ContactModel> contactModelArrayList) {

        this.contactModelArrayList = contactModelArrayList;
        this.context = context;
    }

    @Override
    public int getCount() {
        return contactModelArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return contactModelArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        LayoutInflater layoutInflater =
                (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null){

            convertView = layoutInflater.inflate(R.layout.raw_custom_list,null);

        }

        ImageView imgDp = convertView.findViewById(R.id.img_cust_list);
        TextView tvData = convertView.findViewById(R.id.tv_cust_list);
        tvData.setText("Name "+contactModelArrayList.get(position).getFirstname()+"\n"+" NickName "+
                contactModelArrayList.get(position).getLastname()+"\n"+"Number"+ contactModelArrayList.get(position).getContactNumber());

        Log.e(TAG, "getView: "+contactModelArrayList.get(position).getPhoto() );

        String img = contactModelArrayList.get(position).getPhoto();

        Bitmap image = null;
        if (!img.equals("") && img != null) {
            image = BitmapFactory.decodeFile(img);// decode

            if (image != null)
                imgDp.setImageBitmap(image);// Set image if bitmap
                // is not null
            else {
                imgDp.setImageResource(R.mipmap.ic_launcher_round);
            }
        } else {
            imgDp.setImageResource(R.mipmap.ic_launcher_round);
        }

        return convertView;
    }
}
