package com.a.contentprovider;

public class ContactModel {

    String contactId,contactNumber,firstname,lastname,email,photo;


    public ContactModel(String contactId, String mobilePhone, String displayName, String nickName, String homeEmail, String profilePath) {

        this.contactId=contactId;
        this.contactNumber=mobilePhone;
        firstname=displayName;
        lastname=nickName;
        email=homeEmail;
        photo=profilePath;
    }

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}
