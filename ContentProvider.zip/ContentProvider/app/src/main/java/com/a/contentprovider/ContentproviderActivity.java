package com.a.contentprovider;

import android.app.ProgressDialog;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class ContentproviderActivity extends AppCompatActivity {


    Button btnMyApp;

    ListView listview;

    ArrayList<ContactModel> contactModelArrayList;

    ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contentprovider);

        listview = findViewById(R.id.listview);
       // btnMyApp = findViewById(R.id.btn_myapp);

        contactModelArrayList = new ArrayList<ContactModel>();
 /*       btnMyApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                PackageManager manager = getPackageManager();
                Intent i = manager.getLaunchIntentForPackage("com.demo2");
                i.addCategory(Intent.CATEGORY_LAUNCHER);
                startActivity(i);


            }
        });
*/
        new LoadData().execute();

    }


    private class LoadData extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(ContentproviderActivity.this);
            progressDialog.setMessage("Loading");
            progressDialog.show();
        }

        @Override
        protected Void doInBackground(Void... voids) {

            contactModelArrayList = getData();
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            if (progressDialog.isShowing()) {

                progressDialog.dismiss();
            }
            Log.e("TAG", "onPostExecute: " + contactModelArrayList.size());

            MyContactAdapter myContactAdapter = new MyContactAdapter
                    (ContentproviderActivity.this, contactModelArrayList);
            listview.setAdapter(myContactAdapter);
        }

    }

    private ArrayList<ContactModel> getData() {
        // contact Uri
        Uri uri = ContactsContract.Contacts.CONTENT_URI;

        Cursor contactCursor = getContentResolver().
                query(uri, null, null, null,
                        ContactsContract.Contacts.DISPLAY_NAME + " ASC ");

        if (contactCursor.moveToFirst()) {
            do {


                long contactId = contactCursor.getLong(contactCursor.getColumnIndex("_ID"));
                Uri dataUri = ContactsContract.Data.CONTENT_URI;

                Cursor dataCursor = getContentResolver().query(dataUri, null,
                        ContactsContract.Data.CONTACT_ID + "=" + contactId, null, null);


                String profilePath = "" ;//+ R.mipmap.ic_launcher_round;
                String nickName = null;
                String homePhone = null;

                String mobilePhone = null;
                String workPhone = null;
                String homeEmail = null;
                String workEmail = null;


                if (dataCursor.moveToFirst()) {

                    String displayName = dataCursor.getString(dataCursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                    do {


                        if (dataCursor.getString(dataCursor.getColumnIndex("mimetype")).equals(ContactsContract.CommonDataKinds.Nickname.CONTENT_ITEM_TYPE)) {

                            nickName = dataCursor.getString(dataCursor.getColumnIndex("data1"));

                        }


                        if (dataCursor.getString(dataCursor.getColumnIndex("mimetype")).equals(ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)) {

                            switch (dataCursor.getInt(dataCursor.getColumnIndex("data2"))) {

                                case ContactsContract.CommonDataKinds.Phone.TYPE_HOME:
                                    homePhone = dataCursor.getString(dataCursor.getColumnIndex("data1"));
                                    break;

                                case ContactsContract.CommonDataKinds.Phone.TYPE_WORK:
                                    workPhone = dataCursor.getString(dataCursor.getColumnIndex("data1"));
                                    break;

                                case ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE:
                                    mobilePhone = dataCursor.getString(dataCursor.getColumnIndex("data1"));
                                    break;
                            }
                        }

                        if (dataCursor.getString(dataCursor.getColumnIndex("mimetype")).equals(ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)) {

                            switch (dataCursor.getInt(dataCursor.getColumnIndex("data2"))) {

                                case ContactsContract.CommonDataKinds.Email.TYPE_HOME:
                                    homeEmail = dataCursor.getString(dataCursor.getColumnIndex("data1"));
                                    break;

                                case ContactsContract.CommonDataKinds.Email.TYPE_WORK:
                                    workEmail = dataCursor.getString(dataCursor.getColumnIndex("data1"));
                                    break;

                            }
                        }
                        if (dataCursor.getString(dataCursor.getColumnIndex("mimetype")).equals(ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE)) {

                            byte[] profilePhoto = dataCursor.getBlob(dataCursor.getColumnIndex("data15"));
                            Bitmap bitmap = BitmapFactory.decodeByteArray(profilePhoto, 0, profilePhoto.length);
                            File file = getBaseContext().getCacheDir();
                            File tempFile = new File(file.getPath() + "/myApp" + contactId + ".png");

                            try {
                                FileOutputStream fileOutputStream = new FileOutputStream(tempFile);
                                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);

                            } catch (FileNotFoundException e) {
                                e.printStackTrace();
                            }

                            profilePath = tempFile.getPath();


                        }


                    } while (dataCursor.moveToNext());

                    contactModelArrayList.add(new ContactModel(Long.toString(contactId),
                            mobilePhone, displayName, nickName, homeEmail, profilePath));


                }


            } while (contactCursor.moveToNext());
        }


        return contactModelArrayList;
    }
}
