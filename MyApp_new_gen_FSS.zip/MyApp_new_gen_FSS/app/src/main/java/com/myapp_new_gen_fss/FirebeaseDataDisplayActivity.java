package com.myapp_new_gen_fss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FirebeaseDataDisplayActivity extends AppCompatActivity {

    private DatabaseReference databaseReference;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firebease_data_display);

        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("People");

        listView = findViewById(R.id.list_view);
        final ArrayList<PeopleModel> peopleModelArrayList = new ArrayList<PeopleModel>();

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()){

                    PeopleModel peopleModel = dataSnapshot1.getValue(PeopleModel.class);
                    peopleModelArrayList.add(peopleModel);

                }

                MyFirebaseDataAdapter myFirebaseDataAdapter = new
                        MyFirebaseDataAdapter(FirebeaseDataDisplayActivity.this,peopleModelArrayList);
               listView.setAdapter(myFirebaseDataAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });






    }
}
