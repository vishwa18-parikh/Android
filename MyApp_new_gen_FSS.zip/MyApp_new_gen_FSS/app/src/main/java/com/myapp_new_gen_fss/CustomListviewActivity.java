package com.myapp_new_gen_fss;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class CustomListviewActivity extends AppCompatActivity {


    ListView listView;
    String strLang[] = {"Android", "Java", "PHP", "C", "C++", "Python"};
    int imgData[] = {R.mipmap.ic_launcher_round, R.drawable.ic_java,
            R.drawable.ic_php, R.drawable.ic_c,
            R.drawable.ic_cc, R.drawable.ic_python};

    ArrayList<DataModel> dataModelArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_listview);
        listView = findViewById(R.id.list_view);

        dataModelArrayList = new ArrayList<DataModel>();

        for (int i = 0; i < strLang.length; i++) {

            DataModel dataModel = new DataModel(strLang[i], imgData[i]);
            dataModelArrayList.add(dataModel);

        }

        MyListBaseAdapter myListBaseAdapter = new MyListBaseAdapter(this, dataModelArrayList);
        listView.setAdapter(myListBaseAdapter);
      /*  listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String strLang = parent.getItemAtPosition(position).toString();

                Intent i = new Intent(CustomListviewActivity.this, HomeActivity.class);
                i.putExtra("LANG_KEY", strLang);
                startActivity(i);

            }
        });
*/

    }
}
