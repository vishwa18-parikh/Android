package com.myapp_new_gen_fss;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class ListviewActivity extends AppCompatActivity {


    ListView listView;
    String strLang[] = {"Android", "Java", ".net", "PHP", "C", "C++", "Python","Android", "Java",
            ".net", "PHP", "C", "C++",
            "Python","Android", "Java", ".net", "PHP", "C", "C++", "Python"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview);


        listView = (ListView)findViewById(R.id.listview);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
                this,android.R.layout.simple_list_item_1,strLang);
        listView.setAdapter(arrayAdapter);

    }
}
