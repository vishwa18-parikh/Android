package com.myapp_new_gen_fss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class BottomNavigationActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottom_navigation);
        bottomNavigationView = findViewById(R.id.bottomView);

        bottomNavigationView.setOnNavigationItemSelectedListener
                (new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                if (menuItem.getItemId() == R.id.nav_home){


                    Toast.makeText(BottomNavigationActivity.this, "Home", Toast.LENGTH_SHORT).show();

                }else if (menuItem.getItemId() == R.id.nav_gallery){

                    Toast.makeText(BottomNavigationActivity.this, "Gallery", Toast.LENGTH_SHORT).show();

                } else if (menuItem.getItemId() == R.id.nav_profile){


                    Toast.makeText(BottomNavigationActivity.this, "Profile", Toast.LENGTH_SHORT).show();
            }


                return true;
            }
        });


    }
}
