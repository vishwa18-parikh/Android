package com.myapp_new_gen_fss;

public class PeopleModel {


    String people_id,people_Fn,people_Ln;

    public String getPeople_id() {
        return people_id;
    }

    public void setPeople_id(String people_id) {
        this.people_id = people_id;
    }

    public String getPeople_Fn() {
        return people_Fn;
    }

    public void setPeople_Fn(String people_Fn) {
        this.people_Fn = people_Fn;
    }

    public String getPeople_Ln() {
        return people_Ln;
    }

    public void setPeople_Ln(String people_Ln) {
        this.people_Ln = people_Ln;
    }
}
