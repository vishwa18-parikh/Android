package com.myapp_new_gen_fss;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.GridView;

public class GridviewActivity extends AppCompatActivity {

GridView gridView;

String strLang[] = {"Android","java",".net","PHP","C","C++","python"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gridview);
        gridView = findViewById(R.id.gridview);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,
                R.layout.raw_grid,R.id.tv_data,strLang);

        gridView.setAdapter(arrayAdapter);



    }
}
