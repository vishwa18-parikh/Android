package com.myapp_new_gen_fss;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class VideoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);

        VideoView videoView = findViewById(R.id.video_view);

        String path = "android.resource://"+getPackageName()+"/"+R.raw.never_give_up;
        MediaController mediaController = new MediaController(this);
        videoView.setVideoPath(path);
        videoView.setMediaController(mediaController);
        videoView.start();


    }
}
