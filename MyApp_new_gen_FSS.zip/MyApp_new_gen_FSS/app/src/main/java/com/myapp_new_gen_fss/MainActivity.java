package com.myapp_new_gen_fss;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edtEmail;
    Button btnLogin;
    private ImageView imgLogo;
    Button btnSend;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtEmail = findViewById(R.id.edt_email);
        btnLogin = findViewById(R.id.btn_login);

        imgLogo = findViewById(R.id.img_house);

        btnSend = findViewById(R.id.btn_send);
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /*implicit Intent*/

                Intent  i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.javatpoint.com/"));
                startActivity(i);
               // finish();

            }
        });


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String strEmail = edtEmail.getText().toString();

                if (strEmail.equals("")){
                  //  Toast.makeText(MainActivity.this, "Enter Email id", Toast.LENGTH_SHORT).show();

                    edtEmail.setError("Enter Email Id");
                }else {


                    imgLogo.setImageResource(R.drawable.ic_email);

                    /*explicit Intent*/
                    Intent i = new Intent(MainActivity.this,HomeActivity.class);
                    i.putExtra("USERNAME_KEY",strEmail);
                    startActivity(i);


                  //  Toast.makeText(MainActivity.this, "Email is"+strEmail, Toast.LENGTH_SHORT).show();

                }

            }
        });





    }
}
