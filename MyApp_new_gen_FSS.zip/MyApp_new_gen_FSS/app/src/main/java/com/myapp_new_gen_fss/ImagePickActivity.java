package com.myapp_new_gen_fss;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;

import java.io.IOException;

import de.hdodenhof.circleimageview.CircleImageView;

public class ImagePickActivity extends AppCompatActivity {

    CircleImageView circleImageView;
    Button btnGallery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_pick);

        circleImageView = findViewById(R.id.img_dp);
        btnGallery = findViewById(R.id.btn_img_pick);

        btnGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /*Intent i = new Intent();
                i.setAction(Intent.ACTION_PICK);
                i.setType("image/*");
                startActivityForResult(i, 14);*/


                Intent i = new Intent();
                i.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(i,13);

            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == 14) {

            Uri uri = data.getData();
            circleImageView.setImageURI(uri);

        }
        if (requestCode == 13){

                Bitmap bitmap = (Bitmap) data.getExtras().get("data");
                circleImageView.setImageBitmap(bitmap);

        }

    }
}
