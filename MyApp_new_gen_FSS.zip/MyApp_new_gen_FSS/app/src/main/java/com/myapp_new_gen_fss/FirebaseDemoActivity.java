package com.myapp_new_gen_fss;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FirebaseDemoActivity extends AppCompatActivity {
    EditText edtFn, edtLn;
    Button btnAdd, btnDisplay;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firebase_demo);

        edtFn = findViewById(R.id.etFirstName);
        edtLn = findViewById(R.id.etLastname);
        btnAdd = findViewById(R.id.btn_add);
        btnDisplay = findViewById(R.id.btn_display);

        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("People");

        btnDisplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent  i = new Intent(FirebaseDemoActivity.this,
                        FirebeaseDataDisplayActivity.class);
                startActivity(i);




            }
        });



        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String strFn = edtFn.getText().toString();
                String strLn = edtLn.getText().toString();

                String strKey = databaseReference.push().getKey();

                PeopleModel peopleModel = new PeopleModel();
                peopleModel.setPeople_Fn(strFn);
                peopleModel.setPeople_Ln(strLn);
                peopleModel.setPeople_id(strKey);

                databaseReference.child(strKey).setValue(peopleModel);

            }
        });

    }
}
