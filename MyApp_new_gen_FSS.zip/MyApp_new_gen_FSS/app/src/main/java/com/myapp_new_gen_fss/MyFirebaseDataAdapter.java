package com.myapp_new_gen_fss;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class MyFirebaseDataAdapter extends BaseAdapter {

    Context context;
    ArrayList<PeopleModel> peopleModelArrayList;

    public MyFirebaseDataAdapter(Context context, ArrayList<PeopleModel> peopleModelArrayList) {

    this.context = context;
    this.peopleModelArrayList = peopleModelArrayList;
    }

    @Override
    public int getCount() {
        return peopleModelArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return peopleModelArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        LayoutInflater layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        convertView = layoutInflater.inflate(R.layout.raw__custom_listview,null);

        TextView tvData = convertView.findViewById(R.id.tv_data);
        tvData.setText(peopleModelArrayList.get(position).getPeople_Fn()
                +" "+peopleModelArrayList.get(position).getPeople_Ln());


        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String strId = peopleModelArrayList.get(position).getPeople_id();
                String strFn = peopleModelArrayList.get(position).getPeople_Fn();
                String strLn = peopleModelArrayList.get(position).getPeople_Ln();


                Intent  i = new Intent(context,FirebaseUpdateActivity.class);
                i.putExtra("ID",strId);
                i.putExtra("FN",strFn);
                i.putExtra("LN",strLn);
                context.startActivity(i);


            }
        });



        return convertView;
    }
}
