package com.myapp_new_gen_fss;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SharedPrefActivity extends AppCompatActivity {


    EditText edtEmail, edtPass;
    Button btnSave, btnDisplay;
    private Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shared_pref);

        edtEmail = findViewById(R.id.edt_email);
        edtPass = findViewById(R.id.edt_password);
        btnSave = findViewById(R.id.btn_save);
        btnDisplay = findViewById(R.id.btn_display);

        btnLogout = findViewById(R.id.btn_logout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                SharedPreferences sharedPreferences = getSharedPreferences("MYAPP",Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                editor.remove("EMAIL_KEY");
                editor.commit();

                Intent  i = new Intent(SharedPrefActivity.this, LoginFirebaseActivity.class);
                startActivity(i);
                finish();


            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String strEmail = edtEmail.getText().toString();

                SharedPreferences sharedPreferences =
                        getSharedPreferences("MYAPP", Context.MODE_PRIVATE);

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("EMAIL_KEY",strEmail);
                editor.commit();

                edtEmail.setText("");



            }
        });

        btnDisplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences sharedPreferences =
                        getSharedPreferences("MYAPP", Context.MODE_PRIVATE);

                String strEmail = sharedPreferences.getString("EMAIL_KEY","");
                edtEmail.setText(strEmail);



            }
        });


    }
}
