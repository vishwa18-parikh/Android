package com.myapp_new_gen_fss;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyListBaseAdapter extends BaseAdapter {

    Context context;
    ArrayList<DataModel> dataModelArrayList;

    public MyListBaseAdapter(Context context, ArrayList<DataModel> dataModelArrayList) {

        this.context = context;
        this.dataModelArrayList = dataModelArrayList;
    }

    @Override
    public int getCount() {
        return dataModelArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return dataModelArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {

        LayoutInflater layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null){


            convertView = layoutInflater.inflate(R.layout.raw__custom_listview,null);
        }


        TextView tvdata = (TextView)convertView.findViewById(R.id.tv_data);
        ImageView imgData = (ImageView)convertView.findViewById(R.id.img_data);
        tvdata.setText(dataModelArrayList.get(position).getStrData());
        imgData.setImageResource(dataModelArrayList.get(position).getImgData());

     /*   convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String strLang = dataModelArrayList.get(position).getStrData();
                Intent i = new Intent(context, HomeActivity.class);
                i.putExtra("LANG_KEY", strLang);
                context.startActivity(i);


            }
        });
*/

        return convertView;
    }
}
