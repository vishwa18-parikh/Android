package com.myapp_new_gen_fss;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FirebaseUpdateActivity extends AppCompatActivity
        implements View.OnClickListener {

    EditText edtFn, edtLn;
    Button btnUpdate, btnDelete;
    private String strid;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firebase_update);
        edtFn = findViewById(R.id.etFirstName);
        edtLn = findViewById(R.id.etLastname);
        btnUpdate = findViewById(R.id.btn_update);
        btnDelete = findViewById(R.id.btn_delete);

        btnUpdate.setOnClickListener(this);
        btnDelete.setOnClickListener(this);

        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("People");

        Intent i = getIntent();
        String fn = i.getStringExtra("FN");
        String ln = i.getStringExtra("LN");
        strid = i.getStringExtra("ID");

        edtFn.setText(fn);
        edtLn.setText(ln);

    }

    @Override
    public void onClick(View v) {


        switch (v.getId()){

            case R.id.btn_update:


                String strFn = edtFn.getText().toString();
                String strLn = edtLn.getText().toString();

                PeopleModel peopleModel = new PeopleModel();
                peopleModel.setPeople_Fn(strFn);
                peopleModel.setPeople_Ln(strLn);
                peopleModel.setPeople_id(strid);

                databaseReference.child(strid).setValue(peopleModel);

                Intent i = new Intent(FirebaseUpdateActivity.this,
                        FirebeaseDataDisplayActivity.class);
                startActivity(i);

                break;

            case R.id.btn_delete:


                databaseReference.child(strid).removeValue();

                Intent i1 = new Intent
                        (FirebaseUpdateActivity.this,FirebeaseDataDisplayActivity.class);
                startActivity(i1);

                break;

        }

    }
}
