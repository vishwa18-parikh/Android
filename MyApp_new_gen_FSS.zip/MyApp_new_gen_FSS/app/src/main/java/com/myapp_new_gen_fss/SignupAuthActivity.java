package com.myapp_new_gen_fss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignupAuthActivity extends AppCompatActivity {


    EditText edtUsername, edtPassword;
    Button btnlogin;

    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_auth);


        edtUsername = findViewById(R.id.edt_email);
        edtPassword = findViewById(R.id.edt_password);
        btnlogin = findViewById(R.id.btn_login);

        firebaseAuth = FirebaseAuth.getInstance();

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email  = edtUsername.getText().toString();
                String password= edtPassword.getText().toString();

                firebaseAuth.createUserWithEmailAndPassword(email,password).
                        addOnCompleteListener(SignupAuthActivity.this,
                                new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()){


                            String userkey = firebaseAuth.getUid();





                            Intent i = new Intent(SignupAuthActivity.this, AuthLoginActivity.class);
                            startActivity(i);
                            finish();

                        }


                    }
                });



            }
        });



    }
}
